// copy.h
// written by Derek

#ifndef copy_h
#define copy_h
#include <stdio.h>
#include <string.h>
#include <ncurses.h>

void copyStart();

void copyEnd();

void paste(char * str);

#endif

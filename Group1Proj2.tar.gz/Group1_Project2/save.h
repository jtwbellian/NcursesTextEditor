#ifndef SAVE
#define SAVE

void save(char *filename, int num_lines, char ** text, int h, int w);

#endif
